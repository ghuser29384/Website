# Manual FAO acquisition packet for Painmaps Brazil evidence

This packet contains the manual official FAO/FAOSTAT/FAODATA source acquisition request, manifest templates, validation plan, and report skeleton for the Brazil evidence v2 workflow.

Files:

- `manual-fao-source-acquisition-request.md`
- `manual-fao-source-acquisition-manifest-template.csv`
- `manual-fao-source-acquisition-manifest-template.json`
- `manual-fao-source-validation-plan.md`
- `brazil-evidence-v2-manual-fao-source-acquisition-request-report.md`

The files are candidate-only. They do not contain numeric evidence values and do not promote Brazil.
